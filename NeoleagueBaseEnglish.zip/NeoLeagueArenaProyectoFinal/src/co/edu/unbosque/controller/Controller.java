package co.edu.unbosque.controller;

import co.edu.unbosque.model.ModelFacade;
import co.edu.unbosque.view.ViewFacade;

public class Controller {
	private ModelFacade mf;
	private ViewFacade vf;
	
	public Controller() {
	
	}



}

package co.edu.unbosque.util.exception;

public class InvalidOptionException extends Exception{
	private static final long serialVersionUID = 1L;

	public InvalidOptionException() {
		super("Opción no válida, intente nuevamente.");
	}

	public InvalidOptionException(String mensaje) {
		super(mensaje);
	}
}


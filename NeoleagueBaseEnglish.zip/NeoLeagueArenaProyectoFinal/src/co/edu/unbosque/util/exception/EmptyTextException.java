package co.edu.unbosque.util.exception;

public class EmptyTextException extends Exception {
	private static final long serialVersionUID = 1L;

	public EmptyTextException(String mensaje) {
		super(mensaje);

	}
}

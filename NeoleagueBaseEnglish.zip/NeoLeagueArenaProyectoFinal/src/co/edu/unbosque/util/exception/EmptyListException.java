package co.edu.unbosque.util.exception;

public class EmptyListException extends Exception {
	private static final long serialVersionUID = 1L;

	public EmptyListException() {
		super("La lista está vacía.");
	}

	public EmptyListException(String mensaje) {
		super(mensaje);
	}
}
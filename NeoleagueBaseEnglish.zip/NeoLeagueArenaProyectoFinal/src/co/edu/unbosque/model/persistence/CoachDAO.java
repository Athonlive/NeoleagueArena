package co.edu.unbosque.model.persistence;

import java.util.ArrayList;

import co.edu.unbosque.model.Coach;
import co.edu.unbosque.model.CoachDTO;

public class CoachDAO implements OperationDAO<CoachDTO, Coach>{
	private ArrayList<Coach> coachesList;
	private final String TEXT_FILE_NAME = "Player.csv";
	private final String SERIAL_FILE_NAME ="Player.dat";
	
	public void setPlayersList(ArrayList<Coach> coachesList) {
		this.coachesList = coachesList;
	}
	public CoachDAO() {
		
	}
	

	@Override
	public String showAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<CoachDTO> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean add(CoachDTO newData) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(CoachDTO toDelete) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Coach find(Coach toFind) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean update(CoachDTO previous, CoachDTO newData) {
		// TODO Auto-generated method stub
		return false;
	}
	
}

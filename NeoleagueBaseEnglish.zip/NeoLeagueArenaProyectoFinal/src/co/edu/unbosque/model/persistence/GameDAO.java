package co.edu.unbosque.model.persistence;

import java.util.ArrayList;

import co.edu.unbosque.model.Game;
import co.edu.unbosque.model.GameDTO;

public class GameDAO implements OperationDAO<GameDTO, Game> {
	private ArrayList<Game> gamesList;
	private final String TEXT_FILE_NAME = "Game.csv";
	private final String SERIAL_FILE_NAME = "Game.dat";

	public void setsetGamesList(ArrayList<Game> gamesList) {
		this.gamesList = gamesList;
	}

	public GameDAO() {
		gamesList = new ArrayList<>();

		/*
		 * if (gamesList.isEmpty()) { gamesList.add(new Game(SERIAL_FILE_NAME,
		 * "Apex Legends")); gamesList.add(new Game("Gran Turismo")); gamesList.add(new
		 * Game("Rocket League")); gamesList.add(new Game ("FIFA")); gamesList.add(new
		 * Game("Formula 1"));
		 */

	}
	public ArrayList<Game> getGamesList() {
		return gamesList;
	}

	@Override
	public String showAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<GameDTO> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean add(GameDTO newData) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(GameDTO toDelete) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Game find(Game toFind) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean update(GameDTO previous, GameDTO newData) {
		// TODO Auto-generated method stub
		return false;
	}
	
	
}

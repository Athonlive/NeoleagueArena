package co.edu.unbosque.model.persistence;

import java.util.ArrayList;
import co.edu.unbosque.model.Player;
import co.edu.unbosque.model.PlayerDTO;

public class PlayerDAO implements OperationDAO<PlayerDTO, Player> {
	private ArrayList<Player> playersList;
	private final String TEXT_FILE_NAME = "Player.csv";
	private final String SERIAL_FILE_NAME ="Player.dat";

	public void setPlayersList(ArrayList<Player> playersList) {
		this.playersList = playersList;
	}

	public PlayerDAO() {
		playersList = new ArrayList<>();

	}

	@Override
	public String showAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<PlayerDTO> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean add(PlayerDTO newData) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(PlayerDTO toDelete) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Player find(Player toFind) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean update(PlayerDTO previous, PlayerDTO newData) {
		// TODO Auto-generated method stub
		return false;
	}

}

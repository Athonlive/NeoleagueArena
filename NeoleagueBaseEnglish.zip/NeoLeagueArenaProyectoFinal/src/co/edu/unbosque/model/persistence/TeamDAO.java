package co.edu.unbosque.model.persistence;

import java.util.ArrayList;

import co.edu.unbosque.model.Team;
import co.edu.unbosque.model.TeamDTO;

public class TeamDAO  implements OperationDAO<TeamDTO, Team>{
	private ArrayList<Team> teamsList;
	private final String TEXT_FILE_NAME = "src/Pais.csv";
	private final String SERIAL_FILE_NAME = "src/Pais.dat";
	
	public TeamDAO() {
		teamsList = new ArrayList<>();
	}

	@Override
	public String showAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<TeamDTO> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean add(TeamDTO newData) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(TeamDTO toDelete) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Team find(Team toFind) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean update(TeamDTO previous, TeamDTO newData) {
		// TODO Auto-generated method stub
		return false;
	}
	

}
